import React, { useState } from "react";
import { connect } from "react-redux";
import { saveEmployee } from "../redux/actions/employeeActions";
import { hideAlert, showAlert } from "../redux/actions/alertAction";

const AddEmployee = (props) => {
  const { saveEmployee, history, hideAlert, showAlert } = props;
  console.log({ props });
  const num = Math.floor(Math.random() * 10000);

  const [data, setData] = useState({
    firstName: "virendra" + num,
    email: "virendra" + num + "@gmail.com",
    lastName: "last" + num,
  });

  const onFormSubmit = (e) => {
    e.preventDefault();
    saveEmployee({ ...data }, history, "/");
  };

  const onInputChange = (e) => {
    setData({
      ...data,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div className="border rounded p-4">
      <p className="display-4">Employee Form</p>
      <hr />

      <div>
        <form onSubmit={onFormSubmit}>
          <div className="mb-3">
            <label className="form-label">Email address</label>
            <input
              type="email"
              name="email"
              className="form-control"
              id="exampleInputEmail1"
              aria-describedby="emailHelp"
              onChange={onInputChange}
              value={data.email}
            />
          </div>
          <div className="mb-3">
            <label className="form-label">First Name</label>
            <input
              type="text"
              name="firstName"
              className="form-control"
              id="firstname"
              onChange={onInputChange}
              value={data.firstName}
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Last Name</label>
            <input
              type="text"
              name="lastName"
              className="form-control"
              id="lastName"
              onChange={onInputChange}
              value={data.lastName}
            />
          </div>

          <button type="submit" className="btn btn-primary">
            Save Employee
          </button>
        </form>
      </div>
    </div>
  );
};

const mapStateToProps = (state) => ({});

const mapDispatchToProps = {
  saveEmployee,
  hideAlert,
  showAlert,
};

export default connect(mapStateToProps, mapDispatchToProps)(AddEmployee);
