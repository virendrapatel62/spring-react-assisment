import employeeReducer from "./employeeReducer";
import alertReducer from "./alertReducer";

import { combineReducers } from "redux";

const rootReducer = combineReducers({
  employee: employeeReducer,
  alert: alertReducer,
});

export { rootReducer };
