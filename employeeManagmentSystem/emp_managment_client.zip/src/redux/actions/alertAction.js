import axios from "axios";
import {
  ADD_EMPLOYEE,
  DELETE_EMPLOYEE,
  ERROR_ALERT,
  GET_ALL_EMPLOYEE,
  HIDE_ALERTS,
  ALERT,
} from "./action-types";

const showAlert = (message, alertType) => (dispatch) => {
  dispatch({
    type: ALERT,
    payload: {
      message,
      alertType,
    },
  });
};

const hideAlert = () => (dispatch) => {
  dispatch({
    type: HIDE_ALERTS,
  });
};

export { showAlert, hideAlert };
