import axios from "axios";
import {
  ADD_EMPLOYEE,
  ALERT,
  DELETE_EMPLOYEE,
  GET_ALL_EMPLOYEE,
  UPDATE_EMPLOYEE,
} from "./action-types";

const BASE_URL = "http://localhost:8080/api";
const getAllEmployees = () => async (dispatch) => {
  axios
    .get(BASE_URL + "/employees")
    .then((response) => {
      dispatch({
        type: GET_ALL_EMPLOYEE,
        payload: response.data,
      });
    })
    .catch((err) => {
      console.log(err);
    });
};

const deleteEmployee = (employee) => async (dispatch) => {
  const { id } = employee;
  console.log(employee);
  axios
    .delete(BASE_URL + "/employees/" + id)
    .then((response) => {
      console.log(response);
      dispatch({
        type: DELETE_EMPLOYEE,
        payload: employee,
      });

      dispatch({
        type: ALERT,
        payload: {
          message: "Employee Deleted..",
          alertType: "info",
        },
      });
    })
    .catch((err) => {
      console.log(err);
    });
};

const saveEmployee = (
  employee,
  history = null,
  redirectTo = null,
  successCallBack = () => {},
  failCallBack = () => {}
) => async (dispatch) => {
  console.log(employee);
  axios
    .post(BASE_URL + "/employees", employee)
    .then((response) => {
      console.log(response);
      dispatch({
        type: ADD_EMPLOYEE,
        payload: response.data,
      });

      dispatch({
        type: ALERT,
        payload: {
          message: "Employee Created..",
          alertType: "success",
        },
      });
      if (history) {
        return history.push(redirectTo);
      }
      successCallBack();
    })
    .catch((error) => {
      console.log(error.response.data);
      const { data } = error.response;
      var message = "";
      for (let item in data) {
        message += data[item].message + "\n";
      }
      console.log(message);
      dispatch({
        type: ALERT,
        payload: {
          message: message,
          alertType: "danger",
        },
      });

      failCallBack();
    });
};

const updateEmployee = (
  employee,
  history = null,
  redirectTo = null,
  successCallBack = () => {},
  failCallBack = () => {}
) => async (dispatch) => {
  console.log(employee);
  axios
    .put(BASE_URL + "/employees/" + employee.id, employee)
    .then((response) => {
      console.log(response);
      dispatch({
        type: UPDATE_EMPLOYEE,
        payload: response.data,
      });
      if (history) {
        return history.push(redirectTo);
      }
      successCallBack();
    })
    .catch((err) => {
      console.log(err);
      failCallBack();
    });
};

export { getAllEmployees, deleteEmployee, saveEmployee, updateEmployee };
