import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import {
  saveEmployee,
  getEmployeeByIdFromState,
  updateEmployee,
} from "../redux/actions/employeeActions";
import { hideAlert, showAlert } from "../redux/actions/alertAction";
import { v4 as uuid } from "uuid";
import { useParams } from "react-router-dom";

const AddEmployee = (props) => {
  const { saveEmployee, history, hideAlert, showAlert, updateEmployee } = props;

  console.log({ props });
  const num = Math.floor(Math.random() * 10000);

  const [data, setData] = useState({
    firstName: uuid().substr(0, 6) + num,
    email: uuid().substr(0, 6) + num + "@gmail.com",
    lastName: uuid().substr(0, 6) + num,
    id: null,
  });

  const params = useParams();
  const [empToEdit] = useState(params.id);

  useEffect(() => {
    const employee = getEmployeeByIdFromState(empToEdit);
    if (employee) {
      setData({ ...employee });
    }
  }, [getEmployeeByIdFromState, empToEdit]);

  const onFormSubmit = (e) => {
    e.preventDefault();
    alert(empToEdit);
    if (!empToEdit) return saveEmployee({ ...data }, history, "/");

    return updateEmployee({ ...data }, history, "/");
  };

  const onInputChange = (e) => {
    setData({
      ...data,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div className="border rounded p-4">
      <p className="display-4">Employee Form</p>
      <hr />

      <div>
        <form onSubmit={onFormSubmit}>
          <div className="mb-3">
            <label className="form-label">Email address</label>
            <input
              type="email"
              name="email"
              className="form-control"
              id="exampleInputEmail1"
              aria-describedby="emailHelp"
              onChange={onInputChange}
              value={data.email}
            />
          </div>
          <div className="mb-3">
            <label className="form-label">First Name</label>
            <input
              type="text"
              name="firstName"
              className="form-control"
              id="firstname"
              onChange={onInputChange}
              value={data.firstName}
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Last Name</label>
            <input
              type="text"
              name="lastName"
              className="form-control"
              id="lastName"
              onChange={onInputChange}
              value={data.lastName}
            />
          </div>

          <button type="submit" className="btn btn-primary">
            Save Employee
          </button>
        </form>
      </div>
    </div>
  );
};

const mapStateToProps = (state) => ({});

const mapDispatchToProps = {
  saveEmployee,
  hideAlert,
  showAlert,
  updateEmployee,
};

export default connect(mapStateToProps, mapDispatchToProps)(AddEmployee);
