import React, { Fragment } from "react";
import { connect } from "react-redux";
import { Route, Switch } from "react-router-dom";
import { hideAlert } from "../redux/actions/alertAction";
import AddEmployee from "./AddEmployee";
import AllEmployee from "./AllEmployee";
function Routes({ alert, hideAlert }) {
  return (
    <div className="container mt-3">
      {alert.alertType && (
        <p className={"alert alert-" + alert.alertType}>
          {alert.message}
          <button type="button" onClick={hideAlert} class="btn-close"></button>
        </p>
      )}
      <Fragment>
        <Switch>
          <Route exact path="/" component={AllEmployee}></Route>
          <Route exact path="/add-employee" component={AddEmployee}></Route>
          <Route
            exact
            path="/edit-employee/:id"
            component={AddEmployee}
          ></Route>
        </Switch>
      </Fragment>
    </div>
  );
}

const mapStateToProps = (state) => ({
  alert: state.alert,
});

const mapDispatchToProps = {
  hideAlert,
};

export default connect(mapStateToProps, mapDispatchToProps)(Routes);
