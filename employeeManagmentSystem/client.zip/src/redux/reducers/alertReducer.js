import { ALERT, HIDE_ALERTS } from "../actions/action-types";

const initialState = {
  alertType: "",
  message: "",
};

export default (state = initialState, { type, payload }) => {
  switch (type) {
    case ALERT:
      return { ...payload };
    case HIDE_ALERTS:
      return {};
    default:
      return state;
  }
};
